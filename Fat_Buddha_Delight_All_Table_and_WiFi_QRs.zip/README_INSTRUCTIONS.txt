=====================================================
THE FAT BUDDHA DELIGHT - ALL TABLE & WIFI QR CODES
=====================================================

Included in this ZIP file:

📁 00_PRINT_ALL_11_TABLES_FLYERS.html
   Double-click to open in any browser and press Ctrl+P (or Cmd+P)
   to print all 11 table standee flyers at once on standard A4 or 4x6 paper!

📁 01_Order_Menu_QRs_Only/
   - High-Resolution (1000x1000) PNG QR codes for Tables T01 to T11
   - Scalable Vector Graphics (SVG) for professional printing & Canva

📁 02_WiFi_Access_QRs_Only/
   - High-Resolution (1000x1000) PNG QR codes for Tables T01 to T11
   - WiFi SSID: FatBuddha_Guest_5G
   - WiFi Password: Newdelight@123

📁 03_Printable_Flyers_Order_Menu/
   - Individual Standee Flyers for Tables T01 to T11 (Matches your gold border standee card)

📁 04_Printable_Flyers_WiFi_Access/
   - Individual WiFi Access Standee Flyers with corner accents for Tables T01 to T11

📁 05_Printable_Flyers_Dual_Both/
   - Dual 2-in-1 Standee Flyers showing both Food Menu QR & Free WiFi QR on one flyer

=====================================================
Restaurant: The Fat Buddha Delight
Tables: Table 01 through Table 11
=====================================================
